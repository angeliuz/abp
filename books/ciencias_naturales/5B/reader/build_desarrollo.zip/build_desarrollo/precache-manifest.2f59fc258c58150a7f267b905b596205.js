self.__precacheManifest = [
  {
    "revision": "1fe443cfa913feae4152",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/css/main.a063d234.chunk.css"
  },
  {
    "revision": "1fe443cfa913feae4152",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/js/main.1fe443cf.chunk.js"
  },
  {
    "revision": "53c1a0b62ecfad567476",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/js/1.53c1a0b6.chunk.js"
  },
  {
    "revision": "ba05f780cceb98ddad17",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/css/2.7b9ff837.chunk.css"
  },
  {
    "revision": "ba05f780cceb98ddad17",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/js/2.ba05f780.chunk.js"
  },
  {
    "revision": "dc18284c8a961e7e7966",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/js/runtime~main.dc18284c.js"
  },
  {
    "revision": "ca5037fca35aa6208557ae298064f2b9",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/caja_sesion.ca5037fc.svg"
  },
  {
    "revision": "b9fb8ec6248b88d34ff7ff03d707de07",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/linea.b9fb8ec6.svg"
  },
  {
    "revision": "2e263aaac14d7c949bcbb5575db32443",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_e1.2e263aaa.svg"
  },
  {
    "revision": "3324022121c522bd621171eacadf4065",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/lineas_objetivos.33240221.svg"
  },
  {
    "revision": "f3c9937229edb7fe203e8f4b780d1709",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_e3.f3c99372.svg"
  },
  {
    "revision": "eabd00509bb4c45f5444c3ad1c420392",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_e5.eabd0050.svg"
  },
  {
    "revision": "2d66ac1f2d8399f3ca8ef38ebad3573c",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_e4.2d66ac1f.svg"
  },
  {
    "revision": "85c7cc8ed6dca234d4a6731206da9be6",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_dosier_e2.85c7cc8e.svg"
  },
  {
    "revision": "adc0aa0986b233f450edabf19827a273",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_dosier_e1_2.adc0aa09.svg"
  },
  {
    "revision": "1ec72a5e605c0831002f2e65c1f88aad",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_dosier_e1.1ec72a5e.svg"
  },
  {
    "revision": "3daa0cb4be2e5bab577473b947df1809",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_dosier_e3.3daa0cb4.svg"
  },
  {
    "revision": "700d7bddf97b122fe12c4057f8ad36c9",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_dosier_e4.700d7bdd.svg"
  },
  {
    "revision": "2f13726783756280b862c163224712d8",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/lineas_objetivos_movile.2f137267.svg"
  },
  {
    "revision": "24372dca1b91e43f59b2df1a61691704",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_dosier_e5.24372dca.svg"
  },
  {
    "revision": "bd8318578a86913a63977090de38e7b4",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_dosier_e6.bd831857.svg"
  },
  {
    "revision": "23de8e0d3ab138e807fc8c65a9cc2055",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/caja_blanca.23de8e0d.svg"
  },
  {
    "revision": "d788e03d9d17974e9d436e7b1ebde704",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_e2.d788e03d.svg"
  },
  {
    "revision": "f9149b78cf72699d2e6e3b0d313a439c",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/fondo_e6.f9149b78.svg"
  },
  {
    "revision": "88fc8340cf320e1592d752e3a7848149",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/ccdigitaldelivery-bold.88fc8340.otf"
  },
  {
    "revision": "367c5c6f18242da11f244e36cbbb1cf4",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Colby-StLt.367c5c6f.ttf"
  },
  {
    "revision": "19f0e7fe07dd761dbaa52f83302a3842",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Colby-StReg.19f0e7fe.ttf"
  },
  {
    "revision": "e14ba06545998a5a3ef1a725f7ede4a9",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/colby-bold.e14ba065.ttf"
  },
  {
    "revision": "3ba45e5f43af945f15899fd62c7b9871",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Colby_Com_B.3ba45e5f.ttf"
  },
  {
    "revision": "1f6d130c733138caccaf480b3cd7fe70",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Colby_Com_M.1f6d130c.ttf"
  },
  {
    "revision": "512743695c085edb979fdcf86073c149",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Colby_Com_R.51274369.ttf"
  },
  {
    "revision": "c4c7fa4f3d449c2109b54845ab6fef34",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Colby_Ext_R.c4c7fa4f.ttf"
  },
  {
    "revision": "c21c2ea05ba893dc611e107bcf30a2ca",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Colby_Con_M.c21c2ea0.ttf"
  },
  {
    "revision": "12a2f3cf338283626730f17ac7ae6125",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/hanoded-butterflyball.12a2f3cf.otf"
  },
  {
    "revision": "a0bf3c14ba05cd91760c5b0692d04112",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/durotype-aspiranar-bold.a0bf3c14.otf"
  },
  {
    "revision": "38711b5bb243e894a6d58c8755bb034a",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/MinionPro-Regular.38711b5b.otf"
  },
  {
    "revision": "ff9bdc6054a376fb3169a79b501f7cca",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Montara-Gothic.ff9bdc60.otf"
  },
  {
    "revision": "9c949c31bd2c370cb176ab3fc48e6ee9",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-bold.9c949c31.otf"
  },
  {
    "revision": "7333a4b5fb1f08e7af35fcb0449b62ff",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-extrabold.7333a4b5.otf"
  },
  {
    "revision": "10206d510d31fe2472b8c7f62991a1a2",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-italic.10206d51.otf"
  },
  {
    "revision": "e110d2cc77ae8914c70c34d7c0a7f2e6",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-semibold.e110d2cc.otf"
  },
  {
    "revision": "db946a8f3d63fa2e601a50963d4d667f",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-regular.db946a8f.otf"
  },
  {
    "revision": "008e6bc48c8eaa5d2855d57e6b0b8595",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Ubuntu-B.008e6bc4.ttf"
  },
  {
    "revision": "2759de5c01527bd9730b4d1838e6c938",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Ubuntu-L.2759de5c.ttf"
  },
  {
    "revision": "d8d09723b71ebb22bc31881877609622",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Ubuntu-LI.d8d09723.ttf"
  },
  {
    "revision": "2aaaafd5fe853746266cad7eafcc871e",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Ubuntu-M.2aaaafd5.ttf"
  },
  {
    "revision": "7f0b42d1d6a4d3e646c558185f6711ea",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Ubuntu-R.7f0b42d1.ttf"
  },
  {
    "revision": "1cbf50d848632a690f6404805634afa6",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/ZapfDingbatsStd.1cbf50d8.otf"
  },
  {
    "revision": "6da3b4e2adcbcf2889e59c81d2326a43",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/Ubuntu-RI.6da3b4e2.ttf"
  },
  {
    "revision": "9d4f72483006f07a5a5ae71617bee468",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/IntroRustG-Base.9d4f7248.otf"
  },
  {
    "revision": "95e81355ec7d54f7ce17ca6912fc8536",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/img_005.95e81355.svg"
  },
  {
    "revision": "7ae2f9d015dfbd79ffbcd4d92f5907d8",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/img_004.7ae2f9d0.svg"
  },
  {
    "revision": "62e82fb078e1aeb0497e3c1f77f38294",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/static/media/img_004.62e82fb0.svg"
  },
  {
    "revision": "64c023231c0bcd574e6919135923ebd0",
    "url": "/libros_abp/books/ciencias_naturales/5B/reader/build_desarrollo/index.html"
  }
];