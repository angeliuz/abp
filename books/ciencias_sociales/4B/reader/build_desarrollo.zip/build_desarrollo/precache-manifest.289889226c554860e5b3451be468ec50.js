self.__precacheManifest = [
  {
    "revision": "a5bb6687ceeb13fa373b",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/css/main.4813f314.chunk.css"
  },
  {
    "revision": "a5bb6687ceeb13fa373b",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/js/main.a5bb6687.chunk.js"
  },
  {
    "revision": "dca1a62901ddbe5f0932",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/js/1.dca1a629.chunk.js"
  },
  {
    "revision": "4ab584b54f1d3d4e350b",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/css/2.0ac21cda.chunk.css"
  },
  {
    "revision": "4ab584b54f1d3d4e350b",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/js/2.4ab584b5.chunk.js"
  },
  {
    "revision": "b719bc13971efab38b14",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/js/runtime~main.b719bc13.js"
  },
  {
    "revision": "e6b1d148015cbe44e09dc993ac5dcc1a",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/caja_sesion.e6b1d148.svg"
  },
  {
    "revision": "b9fb8ec6248b88d34ff7ff03d707de07",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/linea.b9fb8ec6.svg"
  },
  {
    "revision": "3324022121c522bd621171eacadf4065",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/lineas_objetivos.33240221.svg"
  },
  {
    "revision": "80209285d082b533390a6b5b5f6d875d",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_e1.80209285.svg"
  },
  {
    "revision": "6a862814c233e1e5a4435c3a4801a159",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_e4.6a862814.svg"
  },
  {
    "revision": "c16f6c80dfd4dd11934538b83555a33d",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_e5.c16f6c80.svg"
  },
  {
    "revision": "aaa6c53b36e10cc9352340b2a3b0c404",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_e6.aaa6c53b.svg"
  },
  {
    "revision": "0db53524130f846d12c0da9fc6e2b451",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_dosier_e1_2.0db53524.svg"
  },
  {
    "revision": "c2b7c0e50d237abb0a1b57091d0b9e77",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_dosier_e2.c2b7c0e5.svg"
  },
  {
    "revision": "e7c84e23529dfd2210215cd82172855f",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_e3.e7c84e23.svg"
  },
  {
    "revision": "3daa0cb4be2e5bab577473b947df1809",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_dosier_e3.3daa0cb4.svg"
  },
  {
    "revision": "0db53524130f846d12c0da9fc6e2b451",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_dosier_e1.0db53524.svg"
  },
  {
    "revision": "2f13726783756280b862c163224712d8",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/lineas_objetivos_movile.2f137267.svg"
  },
  {
    "revision": "700d7bddf97b122fe12c4057f8ad36c9",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_dosier_e4.700d7bdd.svg"
  },
  {
    "revision": "24372dca1b91e43f59b2df1a61691704",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_dosier_e5.24372dca.svg"
  },
  {
    "revision": "bd8318578a86913a63977090de38e7b4",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_dosier_e6.bd831857.svg"
  },
  {
    "revision": "23de8e0d3ab138e807fc8c65a9cc2055",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/caja_blanca.23de8e0d.svg"
  },
  {
    "revision": "9b4d016465a9d85b0a6a65f00ad42ac8",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_e2.9b4d0164.svg"
  },
  {
    "revision": "367c5c6f18242da11f244e36cbbb1cf4",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Colby-StLt.367c5c6f.ttf"
  },
  {
    "revision": "19f0e7fe07dd761dbaa52f83302a3842",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Colby-StReg.19f0e7fe.ttf"
  },
  {
    "revision": "3ba45e5f43af945f15899fd62c7b9871",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Colby_Com_B.3ba45e5f.ttf"
  },
  {
    "revision": "88fc8340cf320e1592d752e3a7848149",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/ccdigitaldelivery-bold.88fc8340.otf"
  },
  {
    "revision": "1f6d130c733138caccaf480b3cd7fe70",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Colby_Com_M.1f6d130c.ttf"
  },
  {
    "revision": "512743695c085edb979fdcf86073c149",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Colby_Com_R.51274369.ttf"
  },
  {
    "revision": "12a2f3cf338283626730f17ac7ae6125",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/hanoded-butterflyball.12a2f3cf.otf"
  },
  {
    "revision": "c21c2ea05ba893dc611e107bcf30a2ca",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Colby_Con_M.c21c2ea0.ttf"
  },
  {
    "revision": "a0bf3c14ba05cd91760c5b0692d04112",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/durotype-aspiranar-bold.a0bf3c14.otf"
  },
  {
    "revision": "9c949c31bd2c370cb176ab3fc48e6ee9",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-bold.9c949c31.otf"
  },
  {
    "revision": "38711b5bb243e894a6d58c8755bb034a",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/MinionPro-Regular.38711b5b.otf"
  },
  {
    "revision": "c4c7fa4f3d449c2109b54845ab6fef34",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Colby_Ext_R.c4c7fa4f.ttf"
  },
  {
    "revision": "ff9bdc6054a376fb3169a79b501f7cca",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Montara-Gothic.ff9bdc60.otf"
  },
  {
    "revision": "db946a8f3d63fa2e601a50963d4d667f",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-regular.db946a8f.otf"
  },
  {
    "revision": "10206d510d31fe2472b8c7f62991a1a2",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-italic.10206d51.otf"
  },
  {
    "revision": "7333a4b5fb1f08e7af35fcb0449b62ff",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-extrabold.7333a4b5.otf"
  },
  {
    "revision": "e14ba06545998a5a3ef1a725f7ede4a9",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/colby-bold.e14ba065.ttf"
  },
  {
    "revision": "d8d09723b71ebb22bc31881877609622",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Ubuntu-LI.d8d09723.ttf"
  },
  {
    "revision": "008e6bc48c8eaa5d2855d57e6b0b8595",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Ubuntu-B.008e6bc4.ttf"
  },
  {
    "revision": "2759de5c01527bd9730b4d1838e6c938",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Ubuntu-L.2759de5c.ttf"
  },
  {
    "revision": "1cbf50d848632a690f6404805634afa6",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/ZapfDingbatsStd.1cbf50d8.otf"
  },
  {
    "revision": "2aaaafd5fe853746266cad7eafcc871e",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Ubuntu-M.2aaaafd5.ttf"
  },
  {
    "revision": "6da3b4e2adcbcf2889e59c81d2326a43",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Ubuntu-RI.6da3b4e2.ttf"
  },
  {
    "revision": "e110d2cc77ae8914c70c34d7c0a7f2e6",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/pixilate-jollygood-proper-condensed-semibold.e110d2cc.otf"
  },
  {
    "revision": "7f0b42d1d6a4d3e646c558185f6711ea",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/Ubuntu-R.7f0b42d1.ttf"
  },
  {
    "revision": "9d4f72483006f07a5a5ae71617bee468",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/IntroRustG-Base.9d4f7248.otf"
  },
  {
    "revision": "0db53524130f846d12c0da9fc6e2b451",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_001.0db53524.svg"
  },
  {
    "revision": "6bd9571bd015cfbcad32553932c9aa1f",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo_001.6bd9571b.svg"
  },
  {
    "revision": "390ed73075b053910bac2002c560ee86",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/flequillo.390ed730.svg"
  },
  {
    "revision": "8f40ea3df73ead422a1be6a3a2a967c3",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/anillo.8f40ea3d.svg"
  },
  {
    "revision": "524995d04ae0037ae9d4be059ea5478e",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/anillo.524995d0.svg"
  },
  {
    "revision": "d205e7dae93fd160e45a28e5a2b4afda",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/imagen.d205e7da.png"
  },
  {
    "revision": "1f16ca7ac1da157c66b571b1ea049d5d",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/espiral.1f16ca7a.svg"
  },
  {
    "revision": "dfe6161637bbf6630913f9fda4c62b88",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/cuadro.dfe61616.svg"
  },
  {
    "revision": "d2504f97af1f690d9513874c329d3d4a",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/imagen_fondo.d2504f97.jpg"
  },
  {
    "revision": "95f70988dbae322bff24bf452ff656c1",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/static/media/fondo.95f70988.jpg"
  },
  {
    "revision": "9caae23289773664c8884f3fea5e0f84",
    "url": "/libros_abp/books/ciencias_sociales/4B/reader/build_desarrollo/index.html"
  }
];